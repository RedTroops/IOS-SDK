//
//  InterstitialViewController.h
//  RedTroops Demo App
//
//  Created by RedTroops on 1/7/15.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InterstitialViewController : UIViewController
- (IBAction)back:(id)sender;

@end
