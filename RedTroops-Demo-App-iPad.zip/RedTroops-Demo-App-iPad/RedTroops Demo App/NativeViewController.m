//
//  NativeViewController.m
//  RedTroops Demo App
//
//  Created by RedTroops on 1/7/15.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import "NativeViewController.h"
#import "RTAdView.h"

@interface NativeViewController ()
@property (nonatomic,strong) RTAdView *native1;
@property (nonatomic,strong) RTAdView *native2;


@end

@implementation NativeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.native1 = [[RTAdView alloc] initWithSize:RTAdNative1to1];
    self.native1.frame = CGRectMake(100,400,300,300);
    [[[UIApplication sharedApplication]keyWindow]addSubview:self.native1];
    [[[UIApplication sharedApplication]keyWindow]bringSubviewToFront:self.native1];
    [self.native1 prepareAd];
    [self.native1 loadRequest:[RTAdRequest request]];
    
    
    self.native2 = [[RTAdView alloc] initWithSize:RTAdNative6to1];
    self.native2.frame = CGRectMake(100,100,300,50);
    [[[UIApplication sharedApplication]keyWindow]addSubview:self.native2];
    [[[UIApplication sharedApplication]keyWindow]bringSubviewToFront:self.native2];
    [self.native2 prepareAd];
    [self.native2 loadRequest:[RTAdRequest request]];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)back:(id)sender {
    [self.native1 removeTheAd];
    [self.native2 removeTheAd];
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
@end
