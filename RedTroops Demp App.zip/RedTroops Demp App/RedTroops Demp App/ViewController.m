//
//  ViewController.m
//  RedTroops Demp App
//
//  Created by RedTroops on 1/26/15.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "/Users/RedTroops3/Desktop/m/RedTroops Demp App/include/RTAudio.h"
#import "/Users/RedTroops3/Desktop/m/RedTroops Demp App/include/RTVideo.h"

@interface ViewController ()

@property (nonatomic, strong) AVPlayerItem *playerItem;

@property (nonatomic,strong) RTVideo *videoAd;

@property (nonatomic,assign) CGFloat heightOfScreen;
@property (nonatomic,assign) CGFloat widthOfScreen;

@end



@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(BOOL)shouldAutorotate
{
    return NO;
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}

- (IBAction)AudioAd:(id)sender {
 
    self.playerItem = [[AVPlayerItem alloc]init];
    RTAudio *player = [[RTAudio alloc]initWithPlayerItem:self.playerItem];
    [player playRTAudioAd];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(RedTroopsAudioAdFinished:)
                                                 name:AVPlayerItemDidPlayToEndTimeNotification
                                               object:self.playerItem];
    
    
    
}

-(void)RedTroopsAudioAdFinished:(NSNotification *) notification {
    
    NSLog(@"Finished");
    [[NSNotificationCenter defaultCenter]removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:self.playerItem];
}




- (IBAction)VideoAd:(id)sender {
    
    [self getScreenSize];
    self.videoAd = [[RTVideo alloc]initWithSize:RTAdVideo];
    self.videoAd .frame = CGRectMake(0, 0, _widthOfScreen*2, _heightOfScreen*2);
    [self.view addSubview:self.videoAd ];
    
    [self.videoAd  prepareAd];
    [self.videoAd  playAd];
    [self.videoAd  addObserver:self forKeyPath:@"frame" options:0 context:NULL];
    
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    NSLog(@"Video ad closed");
    [self.videoAd  removeObserver:self forKeyPath:@"frame"];
}

-(void) getScreenSize
{
    NSString *osVersion = [[UIDevice currentDevice] systemVersion];
    float osVERSION = [osVersion floatValue];
    
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
    
    if (osVERSION >= 8)
    {
        _heightOfScreen = screenHeight;
        _widthOfScreen = screenWidth;
    }
    else
    {
        UIInterfaceOrientation statusBarOrientation =[UIApplication sharedApplication].statusBarOrientation;
        if (statusBarOrientation==3||statusBarOrientation==4)
        {
            _heightOfScreen = screenWidth;
            _widthOfScreen = screenHeight;
        }
        else if (statusBarOrientation==1||statusBarOrientation==2)
        {
            _heightOfScreen = screenHeight;
            _widthOfScreen = screenWidth;
        }
    }
}

@end
