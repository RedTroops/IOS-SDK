//
//  ViewController.h
//  RedTroops Demo App
//
//  Created by RedTroops.
//  Copyright (c) 2014 RedTroops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)showInterstitial:(id)sender;

- (IBAction)showNative:(id)sender;

- (IBAction)showBanner:(id)sender;
@end

