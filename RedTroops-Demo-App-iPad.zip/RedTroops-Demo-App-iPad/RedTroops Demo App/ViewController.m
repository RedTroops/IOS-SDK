//
//  ViewController.m
//  RedTroops Demo App
//
//  Created by RedTroops
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import "ViewController.h"
#import "RTAdView.h"

@interface ViewController ()

@property (nonatomic,strong)RTAdView *adView;
@property (nonatomic,assign) CGFloat heightOfScreen;
@property (nonatomic,assign) CGFloat widthOfScreen;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)ShowPopUp:(id)sender {
    [self getScreenSize];
    self.adView= [[RTAdView alloc] initWithSize:RTAdPopUp];
    self.adView.frame = CGRectMake(0,0,_widthOfScreen,_heightOfScreen);
    [self.view addSubview:self.adView];
    [self.view bringSubviewToFront:self.adView];
    [self.adView prepareAd];
    [self.adView loadRequest:[RTAdRequest request]];
}

-(void) getScreenSize
{
    NSString *osVersion = [[UIDevice currentDevice] systemVersion];
    float osVERSION = [osVersion floatValue];
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
    if (osVERSION >= 8)
    {
        _heightOfScreen = screenHeight;
        _widthOfScreen = screenWidth;
    }
    else
    {
        UIInterfaceOrientation statusBarOrientation =[UIApplication sharedApplication].statusBarOrientation;
        if (statusBarOrientation==4||statusBarOrientation==3)
        {
            _heightOfScreen = screenWidth;
            _widthOfScreen = screenHeight;
        }
        else if (statusBarOrientation==1||statusBarOrientation==2)
        {
            _heightOfScreen = screenHeight;
            _widthOfScreen = screenWidth;
        }
    }
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}

@end
