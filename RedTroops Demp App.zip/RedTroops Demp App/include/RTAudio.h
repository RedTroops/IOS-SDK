//
//  RTAudio.h
//  Demo
//
//  Created by RedTroops.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>

@interface RTAudio : AVPlayer

-(void)playRTAudioAd;

@end
