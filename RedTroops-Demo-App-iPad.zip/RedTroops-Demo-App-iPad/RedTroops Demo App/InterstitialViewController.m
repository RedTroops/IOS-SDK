//
//  InterstitialViewController.m
//  RedTroops Demo App
//
//  Created by RedTroops on 1/7/15.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import "InterstitialViewController.h"
#import "RTAdView.h"

@interface InterstitialViewController ()

@property (nonatomic,strong)RTAdView *ad;

@property (nonatomic,assign) CGFloat heightOfScreen;
@property (nonatomic,assign) CGFloat widthOfScreen;
@end

@implementation InterstitialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self getScreenSize];
    self.ad= [[RTAdView alloc] initWithSize:RTAdPopUp];
    self.ad.frame = CGRectMake(0,0,_widthOfScreen,_heightOfScreen);
    [[[UIApplication sharedApplication]keyWindow]addSubview:self.ad];
    [[[UIApplication sharedApplication]keyWindow]bringSubviewToFront:self.ad];
    [self.ad prepareAd];
    [self.ad loadRequest:[RTAdRequest request]];
    
    // Do any additional setup after loading the view.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void) getScreenSize
{
    NSString *osVersion = [[UIDevice currentDevice] systemVersion];
    float osVERSION = [osVersion floatValue];
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
    if (osVERSION >= 8)
    {
        _heightOfScreen = screenHeight;
        _widthOfScreen = screenWidth;
    }
    else
    {
        UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
        if (orientation == 4 || orientation == 3)
        {
            _heightOfScreen = screenWidth;
            _widthOfScreen = screenHeight;
        }
        else if (orientation == 1 || orientation == 2)
        {
            _heightOfScreen = screenHeight;
            _widthOfScreen = screenWidth;
        }
    }
}

- (IBAction)back:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
@end
