//
//  Banner.h
//  RedTroops Demo App
//
//  Created by RedTroops.
//  Copyright (c) 2014 RedTroops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Banner : UIViewController
- (IBAction)back:(id)sender;

@end
