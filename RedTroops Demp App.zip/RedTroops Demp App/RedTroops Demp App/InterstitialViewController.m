//
//  InterstitialViewController.m
//  RedTroops Demp App
//
//  Created by  RedTroops on 1/27/15.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import "InterstitialViewController.h"
#import "/Users/RedTroops3/Desktop/d/RedTroops Demp App/include/RTAdView.h"

@interface InterstitialViewController ()
@property (nonatomic,assign) CGFloat heightOfScreen;
@property (nonatomic,assign) CGFloat widthOfScreen;
@property (nonatomic,strong) RTAdView *ad;
@end

@implementation InterstitialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self getScreenSize];
    
    self.ad= [[RTAdView alloc] initWithSize:RTAdPopUp];
    self.ad.frame = CGRectMake(0,0,_widthOfScreen,_heightOfScreen);
    [self.view addSubview:self.ad];
    [self.view bringSubviewToFront:self.ad];
    [self.ad prepareAd];
    [self.ad loadRequest];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)back:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];

}
-(void) getScreenSize
{
    NSString *osVersion = [[UIDevice currentDevice] systemVersion];
    float osVERSION = [osVersion floatValue];
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
    if (osVERSION >= 8)
    {
        _heightOfScreen = screenHeight;
        _widthOfScreen = screenWidth;
    }
    else
    {
        UIInterfaceOrientation statusBarOrientation =[UIApplication sharedApplication].statusBarOrientation;
        if (statusBarOrientation==4||statusBarOrientation==3)
        {
            _heightOfScreen = screenWidth;
            _widthOfScreen = screenHeight;
        }
        else if (statusBarOrientation==1||statusBarOrientation==2)
        {
            _heightOfScreen = screenHeight;
            _widthOfScreen = screenWidth;
        }
    }
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
@end
