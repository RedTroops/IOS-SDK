//
//  Native.m
//  RedTroops Demo App
//
//  Created by RedTroops.
//  Copyright (c) 2014 RedTroops. All rights reserved.
//

#import "Native.h"
#import "RTAdView.h"

@interface Native ()
@property (nonatomic,strong) RTAdView *nativeAd1;
@property (nonatomic,strong) RTAdView *nativeAd2;

@end

@implementation Native

- (void)viewDidLoad {
    [super viewDidLoad];

    
    self.nativeAd1 = [[RTAdView alloc] initWithSize:RTAdNative1to1];
    self.nativeAd1.frame = CGRectMake(85,100,50,50);
    [self.view addSubview:self.nativeAd1];
    [self.view bringSubviewToFront:self.nativeAd1];
    [self.nativeAd1 prepareAd];
    [self.nativeAd1 loadRequest:[RTAdRequest request]];
    
    self.nativeAd2 = [[RTAdView alloc] initWithSize:RTAdNative6to1];
    self.nativeAd2.frame = CGRectMake(10,10,300,50);
    [self.view addSubview:self.nativeAd2];
    [self.view bringSubviewToFront:self.nativeAd2];
    [self.nativeAd2 prepareAd];
    [self.nativeAd2 loadRequest:[RTAdRequest request]];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)back:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}
-(BOOL)prefersStatusBarHidden{
    return YES;
}
@end
