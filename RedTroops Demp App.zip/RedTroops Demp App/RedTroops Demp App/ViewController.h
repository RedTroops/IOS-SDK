//
//  ViewController.h
//  RedTroops Demp App
//
//  Created by RedTroops on 1/26/15.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)AudioAd:(id)sender;

@end

