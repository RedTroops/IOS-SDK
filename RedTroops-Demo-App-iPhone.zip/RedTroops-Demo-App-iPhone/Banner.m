//
//  Banner.m
//  RedTroops Demo App
//
//  Created by RedTroops
//  Copyright (c) 2014 RedTroops. All rights reserved.
//

#import "Banner.h"
#import "RTAdView.h"

@interface Banner ()

@property (nonatomic,strong) RTAdView *topBanner;
@property (nonatomic,strong) RTAdView *bottomBanner;


@property (nonatomic,assign) CGFloat heightOfScreen;
@property (nonatomic,assign) CGFloat widthOfScreen;

@end

@implementation Banner

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //adding a Banner to the top pf the screen
    [self getScreenSize];
    self.topBanner = [[RTAdView alloc] initWithSize:RTAdBannerTop];
    self.topBanner.frame = CGRectMake((_widthOfScreen-320)/2,0,320,75);
    [[[UIApplication sharedApplication]keyWindow]addSubview:self.topBanner];
    [[[UIApplication sharedApplication]keyWindow]bringSubviewToFront:self.topBanner];
    [self.topBanner prepareAd];
    [self.topBanner loadRequest:[RTAdRequest request]];
    
    
    //adding a Banner to the bottom of the screen
    self.bottomBanner = [[RTAdView alloc] initWithSize:RTAdBannerTop];
    self.bottomBanner.frame = CGRectMake((_widthOfScreen-320)/2,_heightOfScreen-75,320,75);
    [[[UIApplication sharedApplication]keyWindow]addSubview:self.bottomBanner];
    [[[UIApplication sharedApplication]keyWindow]bringSubviewToFront:self.bottomBanner];
    [self.bottomBanner prepareAd];
    [self.bottomBanner loadRequest:[RTAdRequest request]];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



- (IBAction)back:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];

}
-(BOOL)prefersStatusBarHidden{
    return YES;
}
-(void) getScreenSize
{
    NSString *osVersion = [[UIDevice currentDevice] systemVersion];
    float osVERSION = [osVersion floatValue];
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
    if (osVERSION >= 8)
    {
        _heightOfScreen = screenHeight;
        _widthOfScreen = screenWidth;
    }
    else
    {
        UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
        if (orientation == 4 || orientation == 3)
        {
            _heightOfScreen = screenWidth;
            _widthOfScreen = screenHeight;
        }
        else if (orientation == 1 || orientation == 2)
        {
            _heightOfScreen = screenHeight;
            _widthOfScreen = screenWidth;
        }
    }
}
@end
