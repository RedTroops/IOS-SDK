//
//  BannerViewController.h
//  RedTroops Demp App
//
//  Created by RedTroops on 1/27/15.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BannerViewController : UIViewController
- (IBAction)back:(id)sender;

@end
