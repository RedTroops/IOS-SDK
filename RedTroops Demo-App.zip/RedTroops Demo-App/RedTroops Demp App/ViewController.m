//
//  ViewController.m
//  RedTroops Demp App
//
//  Created by RedTroops on 1/26/15.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(BOOL)shouldAutorotate
{
    return YES;
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}

@end
