//
//  BannerViewController.m
//  RedTroops Demp App
//
//  Created by RedTroops on 1/27/15.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import "BannerViewController.h"
#import "/Users/RedTroops3/Desktop/kkk/RedTroops Demp App/include/RTAdView.h"

@interface BannerViewController ()
@property (nonatomic,assign) CGFloat heightOfScreen;
@property (nonatomic,assign) CGFloat widthOfScreen;
@property (nonatomic,strong) RTAdView *topBanner;
@property (nonatomic,strong) RTAdView *bottomBanner;
@end

@implementation BannerViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self getScreenSize];
        
    float widthOfAd;
    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){
        widthOfAd = _widthOfScreen*0.5;}
    else{
        widthOfAd = 320;}
    float heightOfAd = widthOfAd*(75.0/320);
    float xOfAd = (_widthOfScreen-widthOfAd)/2;
    float yOfAd = _heightOfScreen-heightOfAd;
    
    
    //self.topBanner = [[RTAdView alloc] initWithSize:RTAdBannerTop];
    //self.topBanner.frame = CGRectMake(xOfAd,0,widthOfAd,heightOfAd);
    //[self.view addSubview:self.topBanner];
    //[self.view bringSubviewToFront:self.topBanner];
    //[self.topBanner prepareAd];
    //[self.topBanner loadRequest];
    //[self.topBanner showAd];

    
    self.bottomBanner = [[RTAdView alloc] initWithSize:RTAdBannerBottom];    
    self.bottomBanner.frame = CGRectMake(xOfAd,yOfAd,widthOfAd,heightOfAd);
    [self.view addSubview:self.bottomBanner];
    [self.view bringSubviewToFront:self.bottomBanner];
    [self.bottomBanner prepareAd];
    [self.bottomBanner loadRequest];
    [self.bottomBanner showAd];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (IBAction)back:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];

}
-(void) getScreenSize
{
    NSString *osVersion = [[UIDevice currentDevice] systemVersion];
    float osVERSION = [osVersion floatValue];
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
    if (osVERSION >= 8)
    {
        _heightOfScreen = screenHeight;
        _widthOfScreen = screenWidth;
    }
    else
    {
        UIInterfaceOrientation statusBarOrientation =[UIApplication sharedApplication].statusBarOrientation;
        if (statusBarOrientation==4||statusBarOrientation==3)
        {
            _heightOfScreen = screenWidth;
            _widthOfScreen = screenHeight;
        }
        else if (statusBarOrientation==1||statusBarOrientation==2)
        {
            _heightOfScreen = screenHeight;
            _widthOfScreen = screenWidth;
        }
    }
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
@end
