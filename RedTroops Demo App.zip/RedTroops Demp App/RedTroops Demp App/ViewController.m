//
//  ViewController.m
//  RedTroops Demp App
//
//  Created by RedTroops on 1/26/15.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "RTAudioAd.h"

@interface ViewController ()

@end

AVPlayerItem *playerItem;


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(BOOL)shouldAutorotate
{
    return NO;
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}

- (IBAction)AudioAd:(id)sender {
    
    RTAudioAd *audio = [[RTAudioAd alloc]initWithSize:RTAdAudio];
    [audio playAudioAd];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(playerItemDidReachEnd:)
                                                 name:AVPlayerItemDidPlayToEndTimeNotification
                                               object:playerItem];
    
    
}
-(void)playerItemDidReachEnd:(NSNotification *) notification {
    NSLog(@"The Ad finished");
}
@end
