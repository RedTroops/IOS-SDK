//
//  NativeViewController.m
//  RedTroops Demp App
//
//  Created by RedTroops on 1/27/15.
//  Copyright (c) 2015 RedTroops. All rights reserved.
//

#import "NativeViewController.h"
#import "/Users/RedTroops3/Desktop/m/RedTroops Demp App/include/RTAdView.h"

@interface NativeViewController ()
@property (nonatomic,strong) RTAdView *adView;
@property (nonatomic,strong) RTAdView *adView1;

@end

@implementation NativeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.adView = [[RTAdView alloc] initWithSize:RTAdNative];
    self.adView.frame = CGRectMake(110,120,200,200);
    [self.view addSubview:self.adView];
    [self.view bringSubviewToFront:self.adView];
    [self.adView prepareAd];
    [self.adView loadRequest];
    [self.adView showAd];
    
    self.adView1 = [[RTAdView alloc] initWithSize:RTAdNative];
    self.adView1.frame = CGRectMake(10,10,300,100);
    [self.view addSubview:self.adView1];
    [self.view bringSubviewToFront:self.adView1];
    [self.adView1 prepareAd];
    [self.adView1 loadRequest];
    [self.adView1 showAd];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)back:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];

}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
@end
